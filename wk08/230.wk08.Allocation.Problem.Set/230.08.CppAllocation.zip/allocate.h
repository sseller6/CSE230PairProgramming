/*************************************************************
 * 1. Name:
 *      -your name-
 * 2. Assignment Name:
 *      Practice 08: Allocation
 * 3. Assignment Description:
 *      Allocate an array and then use it
 * 4. What was the hardest part? Be as specific as possible.
 *      -a paragraph or two about how the assignment went for you-
 * 5. How long did it take for you to complete the assignment?
 *      -total time in hours: reading the assignment, submitting, etc.
 **************************************************************/

 /****************************
  * ALLOCATE ONE FLOAT
  ****************************/



/****************************
 * ALLOCATE ARRAY of DOUBLEs
 ****************************/


/****************************
 * DELETE ONE FLOAT
 ****************************/


/****************************
 * DELETE ARRAY of DOUBLEs
 ****************************/
