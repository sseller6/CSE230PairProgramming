/***********************************************************************
 * Source:
 *    Allocate
 * Summary:
 *    Just call the Allocate unit tests
 * Author:
 *    James Helfrich
 ************************************************************************/

 #include "testAllocate.h"
 using namespace std;

/************************************
 * MAIN
 * Simple driver
 ***********************************/
int main()
{
   TestAllocate().run();

   return 0;
}
